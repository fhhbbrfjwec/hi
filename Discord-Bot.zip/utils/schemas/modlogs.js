module.exports = () => {
    _id: {
        channel: String
    }
}